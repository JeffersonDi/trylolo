# gcp-lab
GCP Laboratory (Cool Level)
Simple static web site based on nginx server
